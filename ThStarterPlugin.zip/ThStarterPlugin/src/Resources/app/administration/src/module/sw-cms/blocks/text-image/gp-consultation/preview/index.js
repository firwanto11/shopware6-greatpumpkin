// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/gp-consultation/preview/index.js
import template from "./sw-cms-preview-gp-consultation.html.twig";
import "./sw-cms-preview-gp-consultation.scss";

Shopware.Component.register("sw-cms-preview-gp-consultation", {
  template,
});
