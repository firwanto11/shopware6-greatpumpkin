// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/gp-consultation/component/index.js
import template from "./sw-cms-block-gp-consultation.html.twig";
import "./sw-cms-block-gp-consultation.scss";

Shopware.Component.register("sw-cms-block-gp-consultation", {
  template,
});
