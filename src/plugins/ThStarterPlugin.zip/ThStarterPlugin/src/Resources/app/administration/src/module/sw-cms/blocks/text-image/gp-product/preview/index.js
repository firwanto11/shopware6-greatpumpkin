// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/gp-product/preview/index.js
import template from './sw-cms-preview-gp-product.html.twig';
import './sw-cms-preview-gp-product.scss';

Shopware.Component.register('sw-cms-preview-gp-product', {
    template
});