// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/gp-company-discount/component/index.js
import template from './sw-cms-block-gp-company-discount.html.twig'
import './sw-cms-block-gp-company-discount.scss'

Shopware.Component.register('sw-cms-block-gp-company-discount', {
	template
})