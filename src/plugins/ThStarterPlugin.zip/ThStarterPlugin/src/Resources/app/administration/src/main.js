// CMS Blocks
import "./module/sw-cms/blocks/text-image/image-text-reversed";
import "./module/sw-cms/blocks/text-image/home-hero";
import "./module/sw-cms/blocks/text-image/gp-product";
import "./module/sw-cms/blocks/text-image/gp-achievement";
import "./module/sw-cms/blocks/text-image/gp-achievement-list";
import "./module/sw-cms/blocks/text-image/gp-video";
import "./module/sw-cms/blocks/text-image/gp-company-discount";
import "./module/sw-cms/blocks/text-image/gp-affiliate";
import "./module/sw-cms/blocks/text-image/gp-contact";
import "./module/sw-cms/blocks/text-image/gp-consultation";
