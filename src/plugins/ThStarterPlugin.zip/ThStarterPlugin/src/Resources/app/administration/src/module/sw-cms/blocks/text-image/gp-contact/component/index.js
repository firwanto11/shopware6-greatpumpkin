// <plugin root>/src/Resources/app/administration/src/module/sw-cms/blocks/text-image/gp-contact/component/index.js
import template from './sw-cms-block-gp-contact.html.twig'
import './sw-cms-block-gp-contact.scss'

Shopware.Component.register('sw-cms-block-gp-contact', {
	template
})