<?php declare(strict_types=1);

namespace Sas\BlogModule\Content\Blog;

use Shopware\Core\Framework\DataAbstractionLayer\Indexing\EntityIndexingMessage;

class BlogEntriesIndexingMessage extends EntityIndexingMessage
{
}
