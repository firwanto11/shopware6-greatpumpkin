import template from './sw-cms-el-preview-blog.html.twig';
import './sw-cms-el-preview-blog.scss';

Shopware.Component.register('sw-cms-el-preview-blog', {
    template,
});
