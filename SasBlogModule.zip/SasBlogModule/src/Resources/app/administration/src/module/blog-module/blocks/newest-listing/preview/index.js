import template from './sas-cms-preview-newest-listing.html.twig';
import './sas-cms-preview-newest-listing.scss';

const { Component } = Shopware;

Component.register('sas-cms-preview-newest-listing', {
    template,
});
