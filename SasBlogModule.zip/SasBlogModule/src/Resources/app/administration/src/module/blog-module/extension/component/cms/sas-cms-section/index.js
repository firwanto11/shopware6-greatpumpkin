import template from './sas-cms-section.html.twig';

const { Component } = Shopware;

Component.extend('sas-cms-section', 'sw-cms-section', {
    template,
});
