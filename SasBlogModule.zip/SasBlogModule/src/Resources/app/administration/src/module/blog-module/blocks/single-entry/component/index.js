import template from './sas-cms-block-blog-single-entry.html.twig';
import './sas-cms-block-blog-single-entry.scss';

Shopware.Component.register('sw-cms-block-blog-single-entry', {
    template,
});
