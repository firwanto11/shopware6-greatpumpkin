import template from './sas-cms-block-blog-detail.html.twig';
import './sas-cms-block-blog-detail.scss';

Shopware.Component.register('sw-cms-block-blog-detail', {
    template,
});
