import template from './sas-cms-block-blog.html.twig';
import './sas-cms-block-blog.scss';

Shopware.Component.register('sw-cms-block-blog-listing', {
    template,
});
