import template from './sas-cms-block-newest-listing.html.twig';

const { Component } = Shopware;

Component.register('sw-cms-block-blog-newest-listing', {
    template,
});
